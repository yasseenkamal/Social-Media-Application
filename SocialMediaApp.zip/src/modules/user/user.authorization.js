import { roleTypes } from "../../DB/model/User.model.js";
import { changeRoles } from "./service/user.service.js";



export const endPoint ={

    changeRoles:[roleTypes.admin,roleTypes.superAdmin]
}